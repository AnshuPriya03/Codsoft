package codsoft;
import java.util.*;
import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;
public class Quiz
{
	private int timeremaining=10;
	private Timer timer;
	
	public static void main(String[] args)
	{
		Quiz quiz=new Quiz();
		quiz.startQuiz();
	}
	public void startQuiz()
	{
		timer=new Timer();
		timer.scheduleAtFixedRate(new TimerTask(){
			public void run() {
				if(timeremaining>0) {
					System.out.println("Time remaining: "+timeremaining+" seconds");
					timeremaining--;
				}
				else {
					System.out.println("Time's up! Quiz ended.");
					endQuiz();
				}
			}
		},0,1000);
		int score=0;
		String[][] answers= {{"Virat Kohli","Rohit Sharma","Rahul Dravid","Sachin Tendulkar"},
							  {"static","final","const","constant"},
							  {"initialize","start()","construct()","main()"},
							  {"int","char","float","string"},
							  {"Scanner","InputOutput","IOStream","FileIO"}};
		
		String[][] Questions= {{"Who is called as Hitman of Cricket?"},
				               {"Which keyword is used to define a constant in java"},
				               {"Which method is used to called when an object is created in java"},
				               {"Which of the following is not a primitive datatype in java"},
				               {"Which class is used for input and output operations in java"}};
		
		String[] correctAnswers= {"Rohit Sharma","final","construct()","string","Scanner",};
		JOptionPane.showMessageDialog(null, "Let's play a quiz game!","Welcome",JOptionPane.PLAIN_MESSAGE);
		
		for(int i=0;i<Questions.length;i++)
		{
			String userAnswer=JOptionPane.showInputDialog(null,Questions[i],"Question "+(i+1),JOptionPane.PLAIN_MESSAGE,null,answers[i],null).toString();
			
			if(userAnswer.equals(correctAnswers[i]))
			{
				score+=1;
			}
		}
		JOptionPane.showMessageDialog(null,"Well Done! You scored "+score+" out of "+Questions.length,"Congratulations!",JOptionPane.PLAIN_MESSAGE);
		
	try {
		Thread.sleep(10000);
	}
	catch(InterruptedException e) {
		e.printStackTrace();
	}
		endQuiz();
	}
	public void endQuiz()
	{
		if(timer!=null)
		{
			timer.cancel();
		}
		System.out.println("Quiz ended!");
	}

}
