package codsoft;
import java.util.*;
public class QuizWithTimer {

	public static void main(String[] args) {
		Question[] questions= {
				new Question("Who is called as Hitman of Cricket?",
				new String[]{"Virat Kohli","Rohit Sharma","Rahul Dravid","Sachin Tendulkar"},
				"B",10),
				new Question("Which keyword is used to define a constant in java",
						new String[]{"static","final","const","constant"},
						"B",10),
				new Question("Which method is used to called when an object is created in java",
						new String[]{"initialize","start()","construct()","main()"},
						"C",10),
				new Question("Which of the following is not a primitive datatype in java",
						new String[]{"int","char","float","string"},
						"D",10),
				new Question("Which class is used for input and output operations in java",
						new String[]{"Scanner","InputOutput","IOStream","FileIO"},
						"A",10),
		};
		Quiz q=new Quiz(questions);
		q.startQuiz();

	}

}
