package codsoft;
import java.util.*;
public class Student_grade_calculator 
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		System.out.print("Enter total no. of subjects:");
		int nS=in.nextInt();
		int total=0;
		for(int i=0;i<nS;i++)
		{
			System.out.println("Enter marks obtained in "+(i+1)+" subject: ");
			int marks=in.nextInt();
			total+=marks;
		}

		double averP=(double)total/nS;
		char Grade;
		if(averP>=90)
		{
			Grade='A';
		}
		else if(averP>=80)
		{
			Grade='B';
		}
		else if(averP>=70)
		{
			Grade='C';
		}
		else if(averP>=60)
		{
			Grade='D';
		}
		else if(averP>=50)
		{
			Grade='E';
		}
		else
		{
			Grade='F';
		}
		System.out.println("The total marks obtained in all subjects: "+total);
		System.out.println("The average percentage obtianed: "+averP+"%");
		System.out.println("The grade obtained: "+Grade);
	}
}
